﻿using Cryptography.WebUi.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Cryptography.WebUi.Services
{
    public class CryptoService : ICryptoService
    {
        public async Task<string> Decrypt(string encrypted, string key)
        {

            return await Task.Run(() =>
            {
                var b = Convert.FromBase64String(encrypted);

                var iv = new byte[16];
                var cipher = new byte[16];

                Buffer.BlockCopy(b, 0, iv, 0, iv.Length);
                Buffer.BlockCopy(b, iv.Length, cipher, 0, iv.Length);

                var _key = Encoding.UTF8.GetBytes(key);

                using (var aes = Aes.Create())
                {
                    using (var decryptor = aes.CreateDecryptor(_key, iv))
                    {
                        var result = string.Empty;
                        using (var ms = new MemoryStream(cipher))
                        {
                            using (var cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Read))
                            {
                                using (var sr = new StreamReader(cs))
                                {
                                    result = sr.ReadToEnd();
                                }
                            }
                        }

                        return result;
                    }
                }
            });
        }
        public async Task<string> Decrypt2(string text, string key)
        {

            return await Task.Run(() =>
            {
                byte[] cipherBytes = Convert.FromBase64String(text);
                using (Aes encryptor = Aes.Create())
                {
                    // extract salt (first 16 bytes)
                    var salt = cipherBytes.Take(16).ToArray();
                    // extract iv (next 16 bytes)
                    var iv = cipherBytes.Skip(16).Take(16).ToArray();
                    // the rest is encrypted data
                    var encrypted = cipherBytes.Skip(32).ToArray();
                    Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(key, salt, 100);
                    encryptor.Key = pdb.GetBytes(32);
                    encryptor.Padding = PaddingMode.PKCS7;
                    encryptor.Mode = CipherMode.CBC;
                    encryptor.IV = iv;
                    // you need to decrypt this way, not the way in your question
                    using (MemoryStream ms = new MemoryStream(encrypted))
                    {
                        using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Read))
                        {
                            using (var reader = new StreamReader(cs, Encoding.UTF8))
                            {
                                return reader.ReadToEnd();
                            }
                        }
                    }
                }
            });
        }

        public async Task<string> Encrypt(string text, string key)
        {
            return await Task.Run(() =>
            {
                var _key = Encoding.UTF8.GetBytes(key);

                using (var aes = Aes.Create())
                {
                    using (var encryptor = aes.CreateEncryptor(_key != null ? _key : aes.Key, aes.IV))
                    {
                        using (var ms = new MemoryStream())
                        {
                            using (var cs = new CryptoStream(ms, encryptor, CryptoStreamMode.Write))
                            {
                                using (var sw = new StreamWriter(cs))
                                {
                                    sw.Write(text);
                                }
                            }

                            var iv = aes.IV;

                            var encrypted = ms.ToArray();

                            var result = new byte[iv.Length + encrypted.Length];

                            Buffer.BlockCopy(iv, 0, result, 0, iv.Length);
                            Buffer.BlockCopy(encrypted, 0, result, iv.Length, encrypted.Length);

                            return Convert.ToBase64String(result);
                        }
                    }
                }
            });
        }
    }
}
