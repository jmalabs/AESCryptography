﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Cryptography.WebUi.Services.Interfaces
{
    public interface ICryptoService
    {
        Task<string> Encrypt(string text, string key);
        Task<string> Decrypt(string encrypted, string key);
        Task<string> Decrypt2(string encrypted, string key);
    }
}
